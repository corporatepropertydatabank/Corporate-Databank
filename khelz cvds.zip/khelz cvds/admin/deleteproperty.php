<?php
@session_start();
require_once('../connect.php'); 
if(isset($_GET['id']))
{
$id=$_GET['id'];
$query3 ="select propertyid from property where propertyid = '$id'";
$result3 = mysqli_query($cxn,$query3)
or die ("Couldn’t execute query.");
$nrows3 = mysqli_num_rows($result3);
if($nrows3>0){
for ($i=0;$i<$nrows3;$i++)
{
$n = $i; #add 1 so numbers don’t start with 0
$row3 = mysqli_fetch_assoc($result3);
extract($row3);
}}

$sql="DELETE FROM zone WHERE propertyid='$id'"; 

if (!mysqli_query($cxn,$sql))
  {
  die('Error zone: ' . mysql_error());
  }
  
  $sql="DELETE FROM valuation WHERE propertyid='$id'"; 

if (!mysqli_query($cxn,$sql))
  {
  die('Error valuation: ' . mysql_error());
  }
  
  $sql="DELETE FROM property WHERE propertyid='$id'"; 

if (!mysqli_query($cxn,$sql))
  {
  die('Error student: ' . mysql_error());
  }
  
header("Location: view.php");
}
mysqli_close($cxn);
?> 