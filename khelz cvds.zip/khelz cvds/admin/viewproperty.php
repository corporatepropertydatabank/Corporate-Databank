<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage System</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
	<link href="../css/sb-admin.css" rel="stylesheet">
	<link href="../css/dataTables.responsive.css" rel="stylesheet">
	<link href="../css/dataTables.bootstrap.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/EduSecUserProfile.css" rel="stylesheet" type="text/css">
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <a class="navbar-brand" href="view.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage System</a>
            </div>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                             View Property Information
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                                View Property Information
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="list-group-item active"> Personal Information
                        </div><br>
						<div class="panel-body">
						<div  style="height:300px;width:100%;">
                            <div class="row">
                                <div class="col-lg-12">
                       <div id="txtHint">
					   <section class="content edusec-user-profile">
<div class="row">
	<div class="col-lg-3 table-responsive ">
	<?php 	
 $query = "SELECT *  from (district join area on district.districtid=area.districtid join property on area.areaid=property.areaid join zone on property.propertyid=zone.propertyid join valuation on property.propertyid=valuation.propertyid) where property.propertyid='$_GET[id]'";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
	$nrows = mysqli_num_rows($result);
if($nrows>0){
for ($i=0;$i<$nrows;$i++)
{
$n = $i + 1; #add 1 so numbers don’t start with 0
$row = mysqli_fetch_assoc($result);
extract($row);
}
}
	 ?>
		<div class="col-md-12 text-center">
			<img src="../images/<?php echo $row['propertycondition'];?>" id = 'picture' width='440' height='340' align='center' class='img-thumbnail'  alt="No Image">
			
		</div>
		
	</div>

	<div class="col-lg-9 profile-data">
		<ul class="nav nav-tabs responsive" id = "profileTab">
			<li class="active" id = "personal-tab"><a href="#personal" data-toggle="tab"><i class="fa fa-user"></i> Property Details</a></li>
			<li id = "academic-tab" class="focus"><a href="#academic" data-toggle="tab"><i class="fa fa-graduation-cap"></i> Valuation Details</a></li>
			<li id = "guardians-tab"><a href="#guardians" data-toggle="tab"><i class="fa fa-user"></i> Finance Details</a></li>
							<li ><a href="propertypdf.php?id=<?php echo $_GET['id'];?>" title="PDF [new window]"><i class="fa fa-file-pdf-o"></i> Generate Pdf</a></li>
					</ul>
		 <div id='content3' class="tab-content responsive">
			<div class="tab-pane active" id="personal">
				

<div class="row">
  <div class="col-xs-12">
	<h3 class="page-header">	
	<i class="fa fa-info-circle"></i> <i>Property Details</i>	<div class="pull-right">
					</div>
	</h3>
  </div><!-- /.col -->
</div>

<div class="row">

	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding edusec-bg-row ">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">District</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['districtname'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Location</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['areaname'];?></div>
	  </div>
	</div>

	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Zoning</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['zoning'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Number of Rooms</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['numberofrooms'];?></div>
	  </div>
	</div>


	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">GEA</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['grossfloorarea'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">NIA</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['NIA'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">GIA</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['GIA'];?></div>
	  </div>
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Floor Type</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['floortype'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Garage</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['garage'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Basement</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['basement'];?></div>
	  </div>
	  
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Encumbrance</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['encumbrance'];?></div>
	  </div>
	  
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Topography</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['topography'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Fixtures and Fittings</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['fixturesandfittings'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Property Type</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['propertytype'];?></div>
	  </div>
	  
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Access</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['access'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Yield</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['yield'];?></div>
	  </div>
	</div>

	
</div> <!---Main Row Div--->
	
			</div>
			<div class="tab-pane" id="academic">
				

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h3 class="page-header">	
	<i class="fa fa-info-circle"></i> <i>Valuation Details</i>	<div class="pull-right">
			</div>
	</h3>
  </div><!-- /.col -->
</div>

<div class="row">
<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding edusec-bg-row ">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Method of Valuation</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['methodofvaluation'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Purpose of Valuation</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['purposeofvaluation'];?></div>
	  </div>
	</div>
<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding edusec-bg-row ">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Date of Valuation</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php $date = new DateTime($row["dateofvaluation"]); echo $date->format("F jS, Y");?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Date of Transaction</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php $date = new DateTime($row["dateoftransaction"]); echo $date->format("F jS, Y");?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Type of Tenure</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['typeoftenure'];?></div>
	  </div>
	</div>
</div>
	
			</div>
			<div class="tab-pane" id="guardians">
				
<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h3 class="page-header">	
	<i class="fa fa-info-circle"></i> Finance Details	<div class="pull-right">	</div>
	</h3>
  </div><!-- /.col -->
</div>


<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
  </div><!-- /.col -->
</div>
<div class="row">
	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Rent Per Month</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['rentpermonth']; ?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Market Value</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['marketvalue']; ?></div>
	  </div>
	</div>

	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Property Value</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['askingprice']; ?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Transaction Price</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['transactionprice']; ?></div>
	  </div>
	</div>
</div>
	
			</div>

</div>
				</div>
	</div>
     </div> <!---End Row Div--->
</section>
					   <div>

</div></div></div></div>

                        <!-- /.panel-body -->
                    
                    <!-- /.panel -->
                </div></div>
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/jquery.dataTables.min.js"></script>
    <script src="../js/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
	   <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>
</body>

</html>
