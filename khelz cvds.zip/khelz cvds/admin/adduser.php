<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
  <script src="../js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../css/sweetalert.css">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/jquery-ui.css" rel="stylesheet" />
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                
                <a class="navbar-brand" href="view.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage System</a>
            </div>
           
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Add User
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                                Add User
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
				<?php
include('head.php');
if(isset($_POST['submit']))
{
$sql="INSERT INTO user (username,usertype,password,status)
VALUES
('$_POST[username]','$_POST[usertype]',md5('$_POST[password]'),'active')";
if (!mysqli_query($cxn,$sql))
  {
  die('Error: ' . mysql_error());
  }
								
$selectid =mysqli_query($cxn,"SELECT * FROM user ORDER BY userid DESC;")or die(mysqli_error());
                               // $sql =mysql_query($select)or die(mysql_error());
                                if(mysqli_num_rows($selectid)>0) 
                                {
                                    $row =mysqli_fetch_array($selectid);
                                    $a=$row['userid'];
                                } else 
                                {
                                    $a =1;
                                }
                               
								
$sq="INSERT INTO client (userid,fname,sname,sex,address,contact)
VALUES
('$a','$_POST[fname]','$_POST[sname]','$_POST[sex]','$_POST[address]','$_POST[contact]')";

if (!mysqli_query($cxn,$sq))
  {
  die('Error:1 ' . mysql_error());
  }
        echo "<div class='alert alert-info alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><center><h4>New user has been added</h4></center></div>";
}


?>
                    <div class="panel panel-default">
                        <div class="list-group-item active">
                            Add User 
                        </div>
                        <div  style="height:600px;width:100%">
                          

                                <div class="col-lg-12">
                         
	<section id="content">
	<div class="container">
		<div>
			<div class="col-md-12 ">
			<div class="tab-content">
                               <div class="tab-pane fade in active">
								<br>
	<form  action="" method = "post">	
		<label for="name">UserName</label>
		<input type="text" class="form-control" id="name"  name = "username" placeholder = "UserName">
		<label for="name">usertype</label>
		<input type="text" class="form-control" id="name" value ="client" name = "usertype" readonly>
		<label for="name">Password</label>
		<input type="text" class="form-control" id="name" name = "password" placeholder = "Password">
		<label for="name">FirstName</label>
		<input type="text" class="form-control" id="name" name = "fname" placeholder = "Firstname">
		<label for="name">Surname&nbsp;</label>
		<input type="text" class="form-control" name = "sname" placeholder = "Surname">
		<label for="name">Sex</label>
		<select class="form-control" name ="sex">
		<option>Male</option>
		<option>Female</option>
		</select>
		<label for="name">Address&nbsp;</label>
		<input type="text" class="form-control" name = "address" placeholder = "Address">
		<label for="name">Contact&nbsp;</label>
		<input type="text" class="form-control" name = "contact" placeholder = "Contact">
<div class="form-group"><br>
<center><div class="col-sm-offset-2 col-sm-8">
<input type="submit" class="btn btn-default" name = "submit" value = "Register">
</div></center>
</form>

<?php
mysqli_close($cxn);
?>
                                </div>
                            </div> 
                            </div>
			</div>
		</div>
		
	</div>
	</section>
	
                            </div>
                            <!-- /panel body row -->
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.js"></script>
</body>

</html>
