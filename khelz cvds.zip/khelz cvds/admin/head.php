<?php 
	@session_start();
	
	if($_SESSION['usertype']!='admin'){
echo  "<meta http-equiv=Refresh content=1;url=../index.php>";
echo '</center></td>
  </tr>
</table> ';
#echo "</center>";
exit();
}
	if(!isset($_SESSION['userid'])){
echo'
<table width="400" class=table2 align=center >
  <tr>
    <td> <br><center><font color=red size=3><b>User Acess Denied !!!!!!</b></font></center><br><hr color=green width=300 size=1><center> 
	Your Not Authorised to Acess This Page. <br>
<hr color=green width=300 size=1><font color=#FF0000 size=1> Redirecting <<<<< </font><br><br>';
echo  "<meta http-equiv=Refresh content=1;url=../index.php>";
echo '</center></td>
  </tr>
</table> ';
#echo "</center>";
exit();
}
	include ('../connect.php');
	?>
<head>
<title>Malawi Central Valuation Data Storage System</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	<LINK href="../css/sb-admin.css" rel="stylesheet" type="text/css" />
	

</head>
<body><?php
$sql = "SELECT * FROM (user join client on user.userid=client.userid) WHERE user.userid='$_SESSION[userid]'";
    $result = mysqli_query($cxn, $sql) or die("Error " . mysqli_error($cxn));
	$nrows = mysqli_num_rows($result);
if($nrows>0){
for ($i=0;$i<$nrows;$i++)
{
$n = $i + 1; #add 1 so numbers don’t start with 0
$row = mysqli_fetch_assoc($result);
extract($row);
}}
?>