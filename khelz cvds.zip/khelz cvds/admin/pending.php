<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage System</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
	<link href="../css/dataTables.responsive.css" rel="stylesheet">
	<link href="../css/dataTables.bootstrap.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<script src="../js/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="../css/sweetalert2.min.css">
	<style>
	.selected{
	background-color:skyblue;
	}
	</style>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="view.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage System</a>
            </div>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                             View Pending Properties<div  style="width:10%;margin-right:17%; float:right"><a class="btn btn-block btn-primary" href="addproperty.php" ><i class="fa menu fa-plus"> Add Property</i></a></div>
                        </h1>
						
                        <ul class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                                View Properties
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="list-group-item active">
                            View Properties
                        </div>
                        <div  style="width:100%;">
                            <div class="row">
                                <div class="col-lg-12">
                       <div id="txtHint"></br>
<?php
include('head.php');
 $query = "SELECT *  from (district join area on district.districtid=area.districtid join property on area.areaid=property.areaid join zone on property.propertyid=zone.propertyid join user on user.userid=property.userid join client on user.userid=client.userid) where property.status='disabled'";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
echo "<div style ='width:80%; margin-left:10%;margin-right:10%;'>
<table class='table table-bordered table-hover' id='dataTables-example'>";
?>
<thead>
                                        <tr>
                                           <th>Supplied By</th>
										   <th>District</th>
                                            <th>Location</th>                                            
                                            <th>Property Type</th>
											<th>Rent/Month</th>
											<th>Zoning</th>
											<th>View Details</th>
											<th>Delete</th>
                                            <th>Approve</th>
                                        </tr>
                                    </thead> 
					<?php 
                            
                            while ($row=mysqli_fetch_assoc($result)) {?> 
                            <tr class='odd gradeX'>
								<td><?php echo $row['fname']." ".$row['sname']; ?></td>
								<td><?php echo $row['districtname']; ?></td>
                                <td><?php echo $row['areaname']; ?></td>
								<td><?php echo $row['propertytype']; ?></td>
                                <td><?php echo $row['rentpermonth']; ?></td>
								<td><?php echo $row['zoning']; ?></td>
								<td align="center"><a title="view" href='viewproperty.php?id=<?php echo $row["propertyid"]?>'><i class="menu fa fa-forward "></i></a></td>
								<td align="center"><a title="Delete" href='deleteproperty.php?id=<?php echo $row["propertyid"];?>' onclick="return confirm('are you sure want to delete')"><i class="glyphicon glyphicon-trash"></a></td>
								<td align="center"><a title="Approve" href='approve.php?id=<?php echo $row["propertyid"];?>'><i class="glyphicon glyphicon-save"></a></td>
                            </tr>
						<?php }?>
                                
                               </table>


<?php
mysqli_close($cxn);
?>
</div>

</div></div></div></div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/jquery.dataTables.min.js"></script>
    <script src="../js/dataTables.bootstrap.min.js"></script>

	
	<script type="text/javascript">
    $(document).ready(function(){
        var table = $('#dataTables-example').DataTable();
   });
</script>
</body>

</html>
