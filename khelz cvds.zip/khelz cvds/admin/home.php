<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student Managemenet Information System</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/morris.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><i class=" menu fa fa-graduation-cap"></i>Student MIS</a>
            </div>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php 
			include('leftside.php');
			include('head.php');
			?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            STUDENT MIS <small>Summary Overview</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Home
                            </li>
                        </ol>
                    </div>
                </div>
                <div class="row">
				<?php
 $query = "SELECT count(propertyid) FROM property ";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
                            
                            while ($row=mysqli_fetch_assoc($result)) {
							$count=$row['count(propertyid)'];
							}?>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa  fa-graduation-cap fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $count?></div>
                                        <div>Property</div>
                                    </div>
                                </div>
                            </div>
                            <a href="view.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Properties</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
					 <?php
					 $query = "SELECT count(userid) FROM user ";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
                            
                            while ($row=mysqli_fetch_assoc($result)) {
							$coun=$row['count(userid)'];
							}?>
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="menu-icon fa fa-users fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $coun?></div>
                                        <div>Users</div>
                                    </div>
                                </div>
                            </div>
                            <a href="viewteacher.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Users</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
					<?php
					 $query = "SELECT count(bedid) FROM bed where status='enabled'";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
                            
                            while ($row=mysqli_fetch_assoc($result)) {
							$count=$row['count(bedid)'];
							}?>
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-inbox fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $count;?></div>
                                        <div>Available Beds</div>
                                    </div>
                                </div>
                            </div>
                            <a href="viewbed.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Beds</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
					<?php
					 $query = "SELECT count(allocateid) FROM roomallocation ";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
                            
                            while ($row=mysqli_fetch_assoc($result)) {
							$count=$row['count(allocateid)'];
							}?>
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-support fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $count;?></div>
                                        <div>Allocate to Beds</div>
                                    </div>
                                </div>
                            </div>
                            <a href="viewroomallocation.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Students Allocated</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
					
                </div>
                <!-- /.row -->
                <?php
include('head.php');
?>    
<div style ='width:80%; margin-left:10%;margin-right:10%;'>
<table class='table table-striped table-hover' id='dataTables-example'>
                                    
                            <?php 
                            $query = "SELECT count(userid) FROM user";
							$result = mysqli_query($cxn,$query)or die(mysql_error());
                            while ($row=mysqli_fetch_array($result)) {
							$count=$row['count(userid)'];
							}?>                            
                            
                            <tr class="odd gradeX">
                                            <th>Number of Users</th>
											<td><?php echo $count; ?></td>
											</tr>
											<?php 
                            $query = "SELECT count(studentid) FROM student where sex='female'";
							$result = mysqli_query($cxn,$query)or die(mysql_error());
                            while ($row=mysqli_fetch_array($result)) {
							$count=$row['count(studentid)'];
							}?>                            
                            
                            <tr class="odd gradeX">
                                            <th>Number of Female Students</th>
											<td><?php echo $count; ?></td>
											</tr>
											<tr>
											<?php 
                            $query = "SELECT count(studentid) FROM student where sex='male'";
							$result = mysqli_query($cxn,$query)or die(mysql_error());
                            while ($row=mysqli_fetch_array($result)) {
							$count=$row['count(studentid)'];
							}?>               
											<th>Number of Male Students</th>
                                            <td class="center"><?php echo $count; ?></td>
                                                                  
                                            
                            </tr>
							<?php 
                            $query = "SELECT count(subjectid) FROM subject";
							$result = mysqli_query($cxn,$query)or die(mysql_error());
                            while ($row=mysqli_fetch_array($result)) {
							$count=$row['count(subjectid)'];
							}?>               
											<th>Number of Subjects Offered</th>
                                            <td class="center"><?php echo $count; ?></td>
                                                                  
                                            
                            </tr>
                                    
                               </table>


<?php
mysqli_close($cxn);
?>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->

    <script src="../js/raphael.min.js"></script>
    <script src="../js/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>
	<script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>

</body>

</html>
