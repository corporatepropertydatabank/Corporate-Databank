<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage System</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="../js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../css/sweetalert.css">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/jquery-ui.css" rel="stylesheet" />
	<script type="text/javascript">

function getdistrict(val)
{
  //alert(val); 
 $.ajax({
     type: 'post',
     url: 'finddistrict.php',
     data: {
       get_option:val
     },
     success: function (response) {
       // alert(response);
       document.getElementById("area").innerHTML=response; 
     }
   });
}
</script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                
               <a class="navbar-brand" href="view.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage System</a>
            </div>
           
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
			<?php include 'head.php';?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Edit Property
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                                Edit Property
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="list-group-item active">
                            Edit Property 
                        </div>
                        <div  style="height:1500px;width:100%">
                          

                                <div class="col-lg-12">
                         
	<div class="tab-content">
                                <div class="tab-pane fade in active" >
								<br>
                                    <form role="form" action="editphp.php?id=<?php echo $_GET['id'];?>" method = "post" enctype="multipart/form-data">
		<div class="form-group">
		<table class='table table-striped table-bordered table-hover'>
<tr>
<?php  
$result=mysqli_query($cxn,"SELECT *  from (district join area on district.districtid=area.districtid join property on area.areaid=property.areaid join zone on property.propertyid=zone.propertyid join valuation on property.propertyid=valuation.propertyid) where property.propertyid=$_GET[id]") or die(mysql_error());

                    while($row=mysqli_fetch_array($result)){?>
                    
<td style="width:46%">	
		<label for="name">District</label>
		<select class="form-control" id ="district" name="district" onchange="getdistrict(this.value);">
		<option value="<?php echo $row['districtid'];?>"><?php echo $row['districtname'];?></option>

</select>
		<label for="area">Area</label>
		<select class="form-control" id ="area" name="area">
     <option value="<?php echo $row['areaid'];?>"><?php echo $row['areaname'];?></option>	
	 
</select>
		<label for="name">Property Type</label>
		<input type="text" class="form-control"   name = "propertytype" value="<?php echo $row['propertytype'];?>">
		<label for="name">Number Of Rooms</label>
		<input type="text" class="form-control"  name = "numberofrooms" value="<?php echo $row['numberofrooms'];?>">
		<label for="name">GEA</label>
		<input type="text" class="form-control"  name = "grossfloorarea" value="<?php echo $row['grossfloorarea'];?>">
		<label for="name">NIA</label>
		<input type="text" class="form-control"  name = "NIA" value="<?php echo $row['NIA'];?>">
		<label for="name">GIA</label>
		<input type="text" class="form-control"  name = "GIA" value="<?php echo $row['GIA'];?>">
		<label for="name">Zoning</label>
<select class="form-control" name="zoning">
<option value="<?php echo $row['zoning'];?>"><?php echo $row['zoning'];?></option>
<option>Commercial</option>
<option>Industrial</option>
<option>Agricultural</option>
<option>Residential</option>
</select>

<label for="name">Rent Per Month</label>
		<input type="text" class="form-control"  name = "rentpermonth" value="<?php echo $row['rentpermonth'];?>">
		
		<label for="name">Floor Type</label>
<select class="form-control" name="floortype">
<option><?php echo $row['floortype'];?></option>
<option>Cement screed</option>
<option>Ceramic tiles</option>
<option>Vinyl</option>
<option>Parquet</option>
<option>Quart tile</option>
</select>

<label for="name">Garage</label>
<select class="form-control" name="garage">
<option><?php echo $row['garage'];?></option>
<option>Available</option>
<option>Not Available</option>
</select>

<label for="name">Fixtures and Fittings</label>
<select class="form-control" name="fixturesandfittings">
<option><?php echo $row['fixturesandfittings'];?></option>
<option>Well fitted with services</option>
<option>Partially fitted with services</option>
<option>No services available</option>
</select>

<label for="name">Topography</label>
<select class="form-control" name="topography">
<option><?php echo $row['topography'];?></option>
<option>Generally Flat</option>
<option>Sloppy</option>
</select>

		</td>
<td>
<label for="name">Basement</label>
<select class="form-control" name="basement">
<option><?php echo $row['basement'];?></option>
<option>Available</option>
<option>Not Available</option>
</select>
		<label for="name">Encumbrance</label>
		<select class="form-control" name ="encambrance">
		<option><?php echo $row['encumbrance'];?></option>
		<option>Available</option>
		<option>Not Available</option>
		</select>
		
		
<label for="name">Access</label>
<select class="form-control" name="access">
<option><?php echo $row['access'];?></option>
<option>Tarmac Road</option>
<option>Earth Road</option>
<option>Gravel Road</option>
</select>

<label for="name">Property Value</label>
		<input type="text" class="form-control"   name = "askingprice" value="<?php echo $row['askingprice'];?>">
		
<label for="name">Market Value</label>
		<input type="text" class="form-control"   name = "marketvalue" value="<?php echo $row['marketvalue'];?>">
		
										
										<label for="name">Method of Valuation</label>
										<select class="form-control" name ="methodofvaluation">
										<option><?php echo $row['methodofvaluation'];?></option>
										<option>Comparable</option>
										<option>Income/profit</option>
										<option>Residual</option>
										<option>Cost</option>
										<option>Investment</option>
										<option>Plant and machinery</option>
										</select>
										
										<label for="name">Purpose of Valuation</label>
										<select class="form-control" name ="purposeofvaluation">
										<option><?php echo $row['purposeofvaluation'];?></option>
										<option>Taxation</option>
										<option>Mortgage</option>
										<option>Insurance</option>
										<option>Compensation</option>
										<option>Asking price</option>
										</select>
		
		<label for="name">Date of Valuation</label>
		<input type="text" id="datepicker" class="form-control"   name = "dateofvaluation" value="<?php echo $row['dateofvaluation'];?>">
		<label for="name">Date of Transaction</label>
		<input type="text" id="datepicker1" class="form-control"   name = "dateoftransaction" value="<?php echo $row['dateoftransaction'];?>">
		
		<label for="name">Yield</label>
		<input type="text" class="form-control"   name = "yield" value="<?php echo $row['yield'];?>">
		
		
		<label for="name">Type of Tenure</label>
										<select class="form-control" name ="typeoftenure">
										<option><?php echo $row['typeoftenure'];?></option>
										<option>Leasehold</option>
										<option>Freehold</option>
										</select>
</td>
</tr>
<?php }
                 ?>
</table>
</div>
<div class="form-group">
<center><div class="col-sm-offset-2 col-sm-7">
<button type="submit" class="btn btn-default" name = "submit" value = "Register">UPDATE</button>
</div></center>

</div>
</form>
                                </div>
                            </div>
	
                            </div>
                            <!-- /panel body row -->
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.js"></script>
<script src="../js/jquery-ui.js"></script>
<script>
$( "#datepicker" ).datepicker({
	inline: true
});
</script>
<script>
$( "#datepicker1" ).datepicker({
	inline: true
});
</script>
</body>

</html>
