<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
  <script src="../js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../css/sweetalert.css">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/jquery-ui.css" rel="stylesheet" />
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                
                <a class="navbar-brand" href="view.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage</a>
            </div>
           
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Message
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                               Message
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
				<?php 
 include('head.php');				
 $query = "SELECT *  from messages where meid='$_GET[id]'";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
	$nrows = mysqli_num_rows($result);
if($nrows>0){
for ($i=0;$i<$nrows;$i++)
{
$n = $i + 1; #add 1 so numbers don’t start with 0
$row = mysqli_fetch_assoc($result);
extract($row);
$id=$row['meid'];
$name=$row['name'];
$email=$row['email'];;
$message=$row['message'];
}
}
	 ?>
                    <div class="panel panel-default">
                        <div class="list-group-item active">
                            Message
                        </div>
                        <div  style="height:400px;width:100%">
                          

                                <div class="col-lg-12">
                         
	<section id="content">
	<div class="container">
		<div>
			<div class="col-md-12 ">
			<div class="tab-content">
                               <div class="tab-pane fade in active">
								<br>
	<form  class="form-horizontal">
<fieldset>	
		<div class="form-group">
			<label class="col-md-2 control-label" >Message ID</label>  
			<div class="col-md-4">
			<input type = "text" value = "<?php echo $id;?>" class="form-control input-md" readonly>
			</div>
			</div>
			
			<div class="form-group">
			<label class="col-md-2 control-label" >Full Name</label>  
			<div class="col-md-4">
			<input type = "text" value = "<?php echo $name;?>" class="form-control input-md" readonly>
			</div>
			</div>
			
			<div class="form-group">
			<label class="col-md-2 control-label" >E-mail</label>  
			<div class="col-md-4">
			<input type = "text" value = "<?php echo $email;?>" class="form-control input-md" readonly>
			</div>
			</div>
			
<div class="form-group">
			<label class="col-md-2 control-label" >Message</label>  
			<div class="col-md-10">
			<textarea rows="2" cols="15"  class="form-control input-md" readonly><?php echo $message;?></textarea>
			</div>
			</div>
</fieldset>
</form>

<?php
mysqli_close($cxn);
?>
                                
                            </div> 
                            </div>
			</div>
		</div>
		
	</div>
	</section>
	
                            </div>
                            <!-- /panel body row -->
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.js"></script>
</body>

</html>
