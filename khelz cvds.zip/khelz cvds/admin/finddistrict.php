<?php
$user="root";
$host="localhost";
$password="";
$database = "cvds";
$cxn = mysqli_connect($host,$user,$password,$database)
or die ("Couldn’t connect to server");
       if(isset($_POST['get_option'])){

     $districtname = $_POST['get_option'];
     echo "<option>---Select---</option>";
     $qry=mysqli_query($cxn,"select distinct areaid,areaname from (district join area on district.districtid=area.districtid) where district.districtid='$districtname'");
     while ($row=mysqli_fetch_array($qry)) {?>
     <option value="<?php echo $row['areaid'];?>"><?php echo $row['areaname'];?></option>	
     <?php 
     }
}
 ?>
   