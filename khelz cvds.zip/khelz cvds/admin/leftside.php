<ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $fname.'&nbsp;'.$sname; ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="changepassword.php"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
			<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav" id="side-menu">
                    <li>
                        <a href="view.php"><i class="fa fa-fw fa-dashboard"></i> Home</a>
                    </li>
                    </li>
                    <li>
                        <a href="pending.php"><i class="fa fa-fw fa-university"></i> Pending Property</a>
                    </li>
					
					<li>
                        <a href="message.php"><i class="menu-icon fa fa-envelope"></i> Messages</a>
                    </li>
					<li>
                        <a href="user.php"><i class="menu-icon fa fa-users"></i> Users</a>
                    </li>
					<li>
                        <a href="addlocation.php"><i class="menu-icon fa fa-plus"></i>  Add Location</a>
                    </li>
					<li>
                        <a href="history.php"><i class="menu-icon fa fa-database"></i>  Login History</a>
                    </li>
                </ul>
            </div>