<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage System</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
  <script src="../js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../css/sweetalert.css">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/jquery-ui.css" rel="stylesheet" />
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                
                <a class="navbar-brand" href="home.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage System</a>
            </div>
           
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Add Location
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                                Add Location
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
				
<?php
 include('head.php');
if(isset($_POST['submit']))
{								
$sql="INSERT INTO area (areaname,districtid)
VALUES
('$_POST[area]','$_POST[district]')";

if (!mysqli_query($cxn,$sql))
  {
  die('Error:1 ' . mysql_error());
  }
 echo "<div class='alert alert-info alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><center><h4>New Location has been added</h4></center></div>";
}


?>
                    <div class="panel panel-default">
                        <div class="list-group-item active">
                            Add Location 
                        </div>
                        <div  style="height:400px;width:100%">
                          

                                <div class="col-lg-12">
                         
	<section id="content">
	<div class="container">
		<div>
			<div class="col-md-12 ">
			<div class="tab-content">
                                <div class="tab-pane fade in active" >
								<br>
								<div style ="width:60%; margin-left:20%;margin-right:25%;">
                                    <form role="form"action="" method = "post">
		<div class="form-group">
<td style="width:46%">	
		<label for="name">District</label>
		<select class="form-control" id ="district" name="district" >
		 <option value="">--select--</option>
<?php  
$result=mysqli_query($cxn,"select * from district") or die(mysql_error());

                    while($row=mysqli_fetch_array($result)){?>
                    <option value="<?php echo $row['districtid'];?>"><?php echo $row['districtname'];?></option>
                    
                <?php }
				
mysqli_close($cxn);
                 ?>
</select>
		<label for="name">Area</label>
		<input type="text" class="form-control"  name = "area" placeholder = "Area">
</div>
<div class="form-group">
<center><div class="col-sm-offset-2 col-sm-7">
<button type="submit" class="btn btn-default" name = "submit" value = "Register">Register</button>
</div></center>
</div>
</form>
                                </div>
                            </div>
                        </div>
			</div>
		</div>
		
	</div>
	</section>
	
                            </div>
                            <!-- /panel body row -->
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.js"></script>
</body>

</html>
