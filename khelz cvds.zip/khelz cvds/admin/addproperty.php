<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage System</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
  <script src="../js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../css/sweetalert.css">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/jquery-ui.css" rel="stylesheet" />
	<script type="text/javascript">

function getdistrict(val)
{
  //alert(val); 
 $.ajax({
     type: 'post',
     url: 'finddistrict.php',
     data: {
       get_option:val
     },
     success: function (response) {
       // alert(response);
       document.getElementById("area").innerHTML=response; 
     }
   });
}
</script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                
                <a class="navbar-brand" href="view.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage System</a>
            </div>
           
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Add Property
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                                Add Property
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="list-group-item active">
                            Add Property 
                        </div>
                        <div  style="height:1500px;width:100%">
                          

                                <div class="col-lg-12">
                         
	<section id="content">
	<div class="container">
		<div>
			<div class="col-md-12 ">
			<div class="tab-content">
                               <div style ="width:60%; margin-left:20%;margin-right:20%;">
								<br>
                                    <form role="form" action="addpropertyphp.php?id=<?php echo $_SESSION['userid'];?>" method = "post" enctype="multipart/form-data">
		<div class="form-group">
		<label for="name">District</label>
		<select class="form-control" id ="district" name="district" onchange="getdistrict(this.value);">
		 <option value="">--select--</option>
<?php  
$result=mysqli_query($cxn,"select * from district") or die(mysql_error());

                    while($row=mysqli_fetch_array($result)){?>
                    <option value="<?php echo $row['districtid'];?>"><?php echo $row['districtname'];?></option>
                    
                <?php }
                 ?>
</select>
		<label for="area">Location</label>
		<select class="form-control" id ="area" name="area">
		<?php
		while ($row=mysqli_fetch_array($result)) {?>
     <option value="<?php echo $row['areaid'];?>"><?php echo $row['areaname'];}?></option>	
	 
</select>
		<label for="name">Property Type</label>
		<input type="text" class="form-control"   name = "propertytype" placeholder = "Property Type">
		<label for="name">Number Of Rooms</label>
		<input type="text" class="form-control"  name = "numberofrooms" placeholder = "Number Of Rooms">
		<label for="name">GEA</label>
		<input type="text" class="form-control"  name = "grossfloorarea" placeholder = "GEA">
		<label for="name">NIA</label>
		<input type="text" class="form-control"   name = "NIA" placeholder = "NIA">
		<label for="name">GIA</label>
		<input type="text" class="form-control"   name = "GIA" placeholder = "GIA">
		<label for="name">Zoning</label>
<select class="form-control" name="zoning">
<option>Commercial</option>
<option>Industrial</option>
<option>Agricultural</option>
<option>Residential</option>
</select>

<label for="name">Rent Per Month</label>
		<input type="text" class="form-control"  name = "rentpermonth" placeholder = "Rent Per Month">
		<label for="name">Floor Type</label>
<select class="form-control" name="floortype">
<option>Cement screed</option>
<option>Ceramic tiles</option>
<option>Vinyl</option>
<option>Parquet</option>
<option>Quart tile</option>
</select>

<label for="name">Garage</label>
<select class="form-control" name="garage">
<option>Available</option>
<option>Not Available</option>
</select>

<label for="name">Fixtures and Fittings</label>
<select class="form-control" name="fixturesandfittings">
<option>Well fitted with services</option>
<option>Partially fitted with services</option>
<option>No services available</option>
</select>

<label for="name">Topography</label>
<select class="form-control" name="topography">
<option>Generally Flat</option>
<option>Sloppy</option>
</select>
<label for="name">Basement</label>
<select class="form-control" name="basement">
<option>Available</option>
<option>Not Available</option>
</select>
		<label for="name">Encumbrance</label>
		<select class="form-control" name ="encambrance">
		<option>Available</option>
		<option>Not Available</option>
		</select>
		
		
<label for="name">Access</label>
<select class="form-control" name="access">
<option>Tarmac Road</option>
<option>Earth Road</option>
<option>Gravel Road</option>
</select>

<label for="name">Property Value</label>
		<input type="text" class="form-control"   name = "askingprice" placeholder = "Asking Price">
		
<label for="name">Market Value</label>
		<input type="text" class="form-control"   name = "marketvalue" placeholder = "Market Value">
		
										<div class="form-group">
                                            <label>Property Condition</label>
                                            <input type="file" name="myfile">
                                        </div>
										
										<label for="name">Method of Valuation</label>
										<select class="form-control" name ="methodofvaluation">
										<option>Comparable</option>
										<option>Income/profit</option>
										<option>Residual</option>
										<option>Cost</option>
										<option>Investment</option>
										<option>Plant and machinery</option>
										</select>
										
										<label for="name">Purpose of Valuation</label>
										<select class="form-control" name ="purposeofvaluation">
										<option>Taxation</option>
										<option>Mortgage</option>
										<option>Insurance</option>
										<option>Compensation</option>
										<option>Asking price</option>
										</select>
		
		<label for="name">Date of Valuation</label>
		<input type="text" id="datepicker" class="form-control"   name = "dateofvaluation" placeholder = "Date of Valuation">
		<label for="name">Date of Transaction</label>
		<input type="text" id="datepicker1" class="form-control"   name = "dateoftransaction" placeholder = "Date of Transaction">
		
		<label for="name">Yield</label>
		<input type="text" class="form-control"   name = "yield" placeholder = "Yield">
		
		<label for="name">Transaction Price</label>
		<input type="text" class="form-control"   name = "trans" placeholder = "Transaction Price">
		
		
		<label for="name">Type of Tenure</label>
										<select class="form-control" name ="typeoftenure">
										<option>Leasehold</option>
										<option>Freehold</option>
										<option>Customary Estate</option>
										</select>
</div>
<div class="form-group">
<center><div class="col-sm-offset-2 col-sm-7">
<button type="submit" class="btn btn-default" name = "submit" value = "Register">Register</button>
</div></center>

</div>
</form>
<?php include 'head.php';?>
                                </div>
                            </div>
			</div>
		</div>
		
	</div>
	</section>
	
                            </div>
                            <!-- /panel body row -->
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.js"></script>
<script src="../js/jquery-ui.js"></script>
<script>
$( "#datepicker" ).datepicker({
	inline: true
});
</script>
<script>
$( "#datepicker1" ).datepicker({
	inline: true
});
</script>
</body>

</html>
