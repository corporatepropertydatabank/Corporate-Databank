<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Malawi Central Valuation Data Storage System</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
  <script src="../js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../css/sweetalert.css">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/jquery-ui.css" rel="stylesheet" />
	<script type="text/javascript">

function getdistrict(val)
{
  //alert(val); 
 $.ajax({
     type: 'post',
     url: 'finddistrict.php',
     data: {
       get_option:val
     },
     success: function (response) {
       // alert(response);
       document.getElementById("area").innerHTML=response; 
     }
   });
}
</script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                
                <a class="navbar-brand" href="view.php"><img src="../img/logo.PNG" alt="" width="50" height="50" />    Malawi Central Valuation Data Storage System</a>
            </div>
           
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include('leftside.php');?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Change Password
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                 <a href="view.php">Home</a>
                            </li>
                            <li class="active">
                                Change Password
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="list-group-item active">
                           Change Password
                        </div>
                        <div  style="height:430px;width:100%">
                          

                                <div class="col-lg-12">
                         
	<section id="content">
	<div class="container">
		<div>
			<div class="col-md-12 ">
			<div class="tab-content">
			</br>
                              <?php 
if (isset($_POST['submit'])) {
	$errors = "";
	$oldpassword 	= $_POST['oldpass'];
	$newpassword1	= $_POST['pass1'];
	$newpassword2	= $_POST['pass2'];
	if($newpassword1!==$newpassword2){
		$errors.="<div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>The New Passwords do not Match</div>";
	}

	$user_id = $_SESSION['userid'];
	$res = $cxn->query("SELECT password FROM user WHERE userid=$user_id");
	while ($row = mysqli_fetch_assoc($res)) {
		$cpass = $row['password'];
	}

	if($cpass!==md5($oldpassword)){
		$errors.="<div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>The Current Password is Incorrect</div>";
	}	

	if($errors==""){
		$insertpassword = md5($newpassword1);
		$qry = "UPDATE user SET password='$insertpassword' WHERE userid='$user_id'";
		$cxn->query($qry) or die($qry);
		$errors.="<div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>Password is Renewed</div>";
	}
}

?>

					   <div style ="width:50%; margin-left:25%;margin-right:25%;">
					   <?php 
				if(!isset($_POST['submit'])):
			?>
			
			<?php else: if($errors!=""): ?>

			<?php echo $errors ?>

			<?php endif; endif;?>
<form role="form" action="changepassword.php" autocomplete="off" method="post" style="margin-left: 15px;">
					<div class="form-group">
						<label for="oldpass">Current Password</label>
						<input type="password" class="form-control" id="oldpass" name="oldpass" placeholder="Enter Current Password" value="">
					</div>

					<div class="form-group">
						<label for="pass1">New Password</label>
						<input type="password" class="form-control" id="pass1" name="pass1" placeholder="Enter Password" value="">
					</div>

					<div class="form-group">
						<label for="pass2">Verify New Password</label>
						<input type="password" class="form-control" id="pass2" name="pass2" placeholder="Re-enter Password" value="">
					</div>
		
					<button type="submit" name="submit" class="btn btn-success">Change Password</button>
				</form>

				</div>

<?php include 'head.php';?>
                                </div>
                            </div>
			</div>
		</div>
		
	</div>
	</section>
	
                            </div>
                            <!-- /panel body row -->
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/metisMenu.min.js"></script>
    <script src="../js/sb-admin-2.js"></script>
    <script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.js"></script>
<script src="../js/jquery-ui.js"></script>
<script>
$( "#datepicker" ).datepicker({
	inline: true
});
</script>
<script>
$( "#datepicker1" ).datepicker({
	inline: true
});
</script>
</body>

</html>
