<?php
ob_start();
require_once('tcpdf_include.php');
 include('../connect.php');
$qry = "SELECT *  from (district join area on district.districtid=area.districtid join property on area.areaid=property.areaid join zone on property.propertyid=zone.propertyid join valuation on property.propertyid=valuation.propertyid) where property.propertyid='$_GET[id]'";
  $res = mysqli_query($cxn,$qry)or die(mysql_error());
while ($row = mysqli_fetch_assoc($res)){
	$id = $row['propertyid'];
}
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);;

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Steven Douglas');
$pdf->SetTitle('Malawi Central Valuation Data Storage System');
$pdf->SetSubject('Malawi Central Valuation Data Storage System');
$pdf->SetKeywords('f');

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}


// set font
$pdf->SetFont('courierBI', '', 20);

// add a page
$pdf->AddPage();

$pdf->Write(0, 'Property Information', '', 0, 'C', true, 0, false, false, 0);

$pdf->SetFont('times', '', 10);

// -----------------------------------------------------------------------------

$query = "SELECT *  from (district join area on district.districtid=area.districtid join property on area.areaid=property.areaid join zone on property.propertyid=zone.propertyid join valuation on property.propertyid=valuation.propertyid) where property.propertyid='$_GET[id]'";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
	
while ($row=mysqli_fetch_assoc($result)) {
$tbl = <<<EOD

<table border="0" cellpadding="2" cellspacing="2" nobr="true">
<tr>
		<td  rowspan='4' width="100%" align="center" style=" margin-right:18% ">
		<img src="../images/$row[propertycondition]" height="127px" width="160px"  style="align:center;
  height: auto;
  border: 1px solid blue;
  border-radius: 50px;"/>
		</td>
	</tr>
</table>
<br>
EOD;
$pdf->writeHTML($tbl, true, false, false, false, '');

$tbl = <<<EOD
<!DOCTYPE html>
<h2 style="color:brown;"><i>Property Details</i></h2>
<table style="border:1px solid skyblue;"  cellpadding="3" cellspacing="0" nobr="true" >
 <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>District</b></td>
  <td style="border-right:1px solid skyblue;">$row[districtname]</td>
 </tr>
 <tr>
 <td style="border-right:1px solid skyblue;"><b>Location</b></td>
  <td style="border-right:1px solid skyblue;">$row[areaname]</td>
 </tr>
 <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Zoning</b></td>
  <td style="border-right:1px solid skyblue;">$row[zoning]</td>
 </tr>
 <tr>
  <td style="border-right:1px solid skyblue;"><b>Number of Rooms</b></td>
  <td style="border-right:1px solid skyblue;">$row[numberofrooms]</td>
 </tr style="border-right:1px solid skyblue;">
 
  <tr  style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>GEA</b></td>
  <td style="border-right:1px solid skyblue;">$row[grossfloorarea]</td>
 </tr>
   <tr>
  <td style="border-right:1px solid skyblue;"><b>GIA</b></td>
  <td style="border-right:1px solid skyblue;">$row[GIA]</td>
 </tr>
   <tr  style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>NIA</b></td>
  <td style="border-right:1px solid skyblue;">$row[NIA]</td>
 </tr>
 <tr>
  <td style="border-right:1px solid skyblue;"><b>Floor Type</b></td>
  <td style="border-right:1px solid skyblue;">$row[floortype]</td>
 </tr>
  <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Garage</b></td>
  <td style="border-right:1px solid skyblue;">$row[garage]</td>
 </tr>
  <tr>
  <td style="border-right:1px solid skyblue;"><b>Basement</b></td>
  <td style="border-right:1px solid skyblue;">$row[basement]</td>
 </tr>
  <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Encumbrance</b></td>
  <td style="border-right:1px solid skyblue;">$row[encumbrance]</td>
 </tr>
  <tr>
  <td style="border-right:1px solid skyblue;"><b>Topography</b></td>
  <td style="border-right:1px solid skyblue;">$row[topography]</td>
 </tr> 
 <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Fixtures and Fittings</b></td>
  <td style="border-right:1px solid skyblue;">$row[fixturesandfittings]</td>
 </tr>
  <tr>
  <td style="border-right:1px solid skyblue;"><b>Property Type</b></td>
  <td style="border-right:1px solid skyblue;">$row[propertytype]</td>
 </tr>
  <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Access</b></td>
  <td style="border-right:1px solid skyblue;">$row[access]</td>
 </tr>
  <tr>
  <td style="border-right:1px solid skyblue;"><b>Yield</b></td>
  <td style="border-right:1px solid skyblue;">$row[yield]</td>
 </tr>
</table>
<br>
EOD;
$pdf->writeHTML($tbl, true, false, false, false, '');

$tbl = <<<EOD
<h2 style="color:brown;"><i>Valuation Details</i></h2>
<table style="border:1px solid skyblue;" cellpadding="3" cellspacing="0" nobr="true" >
 <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Method of Valuation</b></td>
  <td style="border-right:1px solid skyblue;">$row[methodofvaluation]</td>
 </tr>
 <tr>
 <td style="border-right:1px solid skyblue;"><b>Date of Valuation</b>
 </td>
  <td style="border-right:1px solid skyblue;">$row[dateofvaluation]</td>
 </tr>
 <tr style="background-color:skyblue">
  <td style="border-right:1px solid skyblue;"><b>Purpose of Valuation</b></td>
  <td style="border-right:1px solid skyblue;">$row[purposeofvaluation]</td>
 </tr>
 <tr>
  <td style="border-right:1px solid skyblue;"><b>Date of Transaction</b></td>
  <td style="border-right:1px solid skyblue;">$row[dateoftransaction]</td>
 </tr>
  <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Type of Tenure</b></td>
  <td style="border-right:1px solid skyblue;">$row[typeoftenure]</td>
 </tr>
</table>
<br>
EOD;
$pdf->writeHTML($tbl, true, false, false, false, '');

$tbl = <<<EOD
<h2 style="color:brown;"><i>Finance Details</i></h2>
<table style="border:1px solid skyblue;" cellpadding="3" cellspacing="0" nobr="true">
 <tr style="background-color:skyblue">
  <td style="border-right:1px solid skyblue;"><b>Rent per Month</b></td>
  <td style="border-right:1px solid skyblue;"> $row[rentpermonth]</td>
 </tr>
 <tr>
 <td style="border-right:1px solid skyblue;"><b>Market Value</b></td>
  <td style="border-right:1px solid skyblue;">$row[marketvalue]</td>
 </tr>
 <tr style="background-color:skyblue;">
  <td style="border-right:1px solid skyblue;"><b>Property Value</b></td>
  <td style="border-right:1px solid skyblue;">$row[askingprice]</td>
 </tr>
 <tr>
 <td style="border-right:1px solid skyblue;"><b>Transaction Price</b></td>
  <td style="border-right:1px solid skyblue;">$row[transactionprice]</td>
 </tr>
</table>
<br>
EOD;
$pdf->writeHTML($tbl, true, false, false, false, '');
}
ob_end_clean();
$pdf->Output('property report.pdf', 'D');
ob_end_flush();
?>