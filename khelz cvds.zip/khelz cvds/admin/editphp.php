<?php
@session_start();
include("head.php");
if(isset($_POST['submit']))
{					
$sql="UPDATE property SET propertytype='$_POST[propertytype]',numberofrooms='$_POST[numberofrooms]',grossfloorarea='$_POST[grossfloorarea]',rentpermonth='$_POST[rentpermonth]',floortype='$_POST[floortype]',garage='$_POST[garage]',basement='$_POST[basement]',encumbrance='$_POST[encambrance]',fixturesandfittings='$_POST[fixturesandfittings]',access='$_POST[access]',topography='$_POST[topography]',askingprice='$_POST[askingprice]',marketvalue='$_POST[marketvalue]',NIA='$_POST[NIA]',GIA='$_POST[GIA]' where propertyid='$_GET[id]'";

if (!mysqli_query($cxn,$sql))
  {
  die('Error:5 ' . mysql_error());
  }
  
$sq="UPDATE zone SET zoning='$_POST[zoning]' where propertyid='$_GET[id]' ";

if (!mysqli_query($cxn,$sq))
  {
  die('Error: ' . mysql_error());
  }
  
  $qry="UPDATE valuation SET purposeofvaluation='$_POST[purposeofvaluation]',methodofvaluation='$_POST[methodofvaluation]',dateofvaluation='$_POST[dateofvaluation]',yield='$_POST[yield]',dateoftransaction='$_POST[dateoftransaction]',typeoftenure='$_POST[typeoftenure]'  where propertyid=$_GET[id]";

if (!mysqli_query($cxn,$qry))
  {
  die('Error:1 ' . mysql_error());
  }
header("Location: viewproperty.php?id=".$_GET['id'] );
}

mysqli_close($cxn);

?>