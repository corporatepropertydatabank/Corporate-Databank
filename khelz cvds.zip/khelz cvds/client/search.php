<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Malawi Central Valuation Data Storage System</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Bootstrap 3 template for corporate business" />
<!-- css -->
<link href="../css/bootstrap.css" rel="stylesheet" />
<link href="../css/cubeportfolio.min.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />
<link href="../css/page.css" rel="stylesheet" />


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>
<body>


<div id="wrapper">
	<header>
			<div class="top">
				<div class="container">
					<div class="row">
					<center>
						<h2 class="text-info">Malawi Central Valuation Data Storage</h2>
						</center>
					</div>
				</div>
			</div>	
			
        <div class="navbar navbar-default navbar-static-top" style="color:#fff;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                     <a class="navbar-header" href="home.php"><img src="../img/logo.PNG" alt="" width="100" height="100" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="home.php"><i class="fa fa-home"></i> Home</a></li>
						<li><a href="addproperty.php"><i class="fa fa-plus"></i>  Add Property</a></li>
                        <li><a href="contact.php"><i class="fa fa-phone"></i>  Contact</a></li>
                        <li><a href="changepassword.php"><i class="fa fa-fw fa-gear"></i> Change Password</a></li>
                        <li><a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log out [<?php echo $fname.'&nbsp;'.$sname;?>]</a></li>
            </ul>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="home.php"><i class="fa fa-home"></i>  Home</a><i class="icon-angle-right"></i></li>
					<li class="active">Property List</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
	<section id="content2">
	<div class="container" >
	<?php
	$loc=$_GET['l'];
	$qry=("SELECT districtname FROM district  where districtid='$_GET[c]'");
$results = $cxn->query($qry);
$row = mysqli_fetch_array($results);
$district=$row['districtname'];
?>
    <center><h2>Results of Property available in <img src="../images/search.png" alt="search" width="50px"><?php echo $_GET['l']; ?> , <?php echo $district; ?></h2></center>
    <article class="vendor list js-vendor-list-vendor-panel">
	<?php
	
			  $query = "SELECT *  from (district join area on district.districtid=area.districtid join property on area.areaid=property.areaid join zone on property.propertyid=zone.propertyid join valuation on property.propertyid=valuation.propertyid) where district.districtid='$_GET[c]' and area.areaname like '%{$loc}%' and property.status='enabled'";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
	$nrows = mysqli_num_rows($result);
if($nrows>0){
	while ($row=mysqli_fetch_assoc($result)) {
?>	
		<a class="vendor__inner" href="viewproperty.php?id=<?php echo $row["propertyid"];?>" style="background-color:#1ff;margin-bottom:0.5%">
            <div class="vendor__image js-fire-click-tracking-event">
                        
    
<img class="lazy-loaded" alt="Flavor Junction" src="../images/<?php echo $row['propertycondition'];?>" height="80" width="80">
</div>

            <div class="vendor__details">
                <div class="vendor__title">
    <span class="vendor__name js-fire-click-tracking-event">
        <?php echo $row['zoning'];?>
    </span>

    <div class="clear"></div>
</div>
                <ul class="vendor__cuisines">
    <li><?php echo $row['grossfloorarea'];?></ul>

                <div class="vendor__details__footer">
                    
                    <div class="vendor__ratings_recommendation__container">
                        <div class="vendor__ratings">
                        
    
    <div class="rating  ">
         <span class="review">
                 <span>Number of Rooms (<?php echo $row['numberofrooms'];?>)</span>
         </span>
            </div>
</div>
    </div>
                </div>
            </div>

            <div class="vendor__info">
                                    <div class="vendor__new"><span><?php $date = new DateTime($row["dateofvaluation"]); echo $date->format("Y");?></span></div>
                
                
<ul class="vendor__availability">
            
        
        <li class="vendor__delivery-time">
            <span>
                                    <span class="delivery-time-label">

                        Access: <span class="minutes"><?php echo $row["access"];?></span>
                    </span>
                            </span>
        </li>
    </ul>
            </div>
        </a>
		<?php }
		}
else{
echo "<br><div class='alert alert-info alert-dismissable'><center>No Property Available</center></div>";
}
		?>
    </article>  
	</div>
	</section>
	<?php include("../footer.php");?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.min.js"></script>
<script src="../js/modernizr.custom.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.appear.js"></script>
<script src="../js/stellar.js"></script>
<script src="../js/classie.js"></script>
<script src="../js/uisearch.js"></script>
<script src="../js/jquery.cubeportfolio.min.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>
	
</body>
</html>