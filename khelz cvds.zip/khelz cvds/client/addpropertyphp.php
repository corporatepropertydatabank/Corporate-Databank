<?php
include("../connect.php");
if(isset($_POST['submit']))
{
$file_upload="true";
$file_up_size=$_FILES["myfile"]["size"];

if($_FILES["myfile"]["size"]>25000000)
{
$msg="Your uploaded file is more than 250kb<br>";
$file_upload="false";
}
if(!($_FILES["myfile"]["type"]=="image/jpeg" or$_FILES["myfile"]["type"]=="image/gif"))
{
$msg="ypur uploaded file must be jpg";
$file_upload="false";
}
$file_name=$_FILES["myfile"]["size"].$_FILES["myfile"]["name"];
$add="../images/$file_name";

if($file_upload=="true")
{
if(move_uploaded_file($_FILES["myfile"]["tmp_name"],$add))
{;
}
else{
echo "failed";
}
}						
$sql="INSERT INTO property (userid,propertytype,propertycondition,numberofrooms,grossfloorarea,rentpermonth,floortype,garage,basement,encumbrance,areaid,fixturesandfittings,access,topography,askingprice,marketvalue,NIA,GIA,transactionprice,status)
VALUES
('$_GET[id]','$_POST[propertytype]','$file_name','$_POST[numberofrooms]','$_POST[grossfloorarea]','$_POST[rentpermonth]','$_POST[floortype]','$_POST[garage]','$_POST[basement]','$_POST[encambrance]',
'$_POST[area]','$_POST[fixturesandfittings]','$_POST[access]','$_POST[topography]','$_POST[askingprice]','$_POST[marketvalue]','$_POST[NIA]','$_POST[GIA]','$_POST[trans]','disabled')";

if (!mysqli_query($cxn,$sql))
  {
  die('Error:1 ' . mysql_error());
  }
 $selectid =mysqli_query($cxn,"SELECT * FROM property ORDER BY propertyid DESC;")or die(mysqli_error());
                               // $sql =mysql_query($select)or die(mysql_error());
                                if(mysqli_num_rows($selectid)>0) 
                                {
                                    $row =mysqli_fetch_array($selectid);
                                    $a=$row['propertyid'];
                                } else 
                                {
                                    $a =1;
                                }
$sq="INSERT INTO zone (zoning,propertyid)
VALUES
('$_POST[zoning]','$a')";

if (!mysqli_query($cxn,$sq))
  {
  die('Error: ' . mysql_error());
  }
   $selectid =mysqli_query($cxn,"SELECT * FROM property ORDER BY propertyid DESC;")or die(mysqli_error());
                               // $sql =mysql_query($select)or die(mysql_error());
                                if(mysqli_num_rows($selectid)>0) 
                                {
                                    $row =mysqli_fetch_array($selectid);
                                    $a=$row['propertyid'];
                                } else 
                                {
                                    $a =1;
                                }
  $qry="INSERT INTO valuation (purposeofvaluation,methodofvaluation,dateofvaluation,yield,dateoftransaction,typeoftenure,propertyid)
VALUES
('$_POST[purposeofvaluation]','$_POST[methodofvaluation]','$_POST[dateofvaluation]','$_POST[yield]','$_POST[dateoftransaction]','$_POST[typeoftenure]','$a')";

if (!mysqli_query($cxn,$qry))
  {
  die('Error:1 ' . mysql_error());
  }
header("Location: addproperty2.php" );
}

mysqli_close($cxn);

?>