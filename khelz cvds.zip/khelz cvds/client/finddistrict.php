<?php
$user="id20130090_root";
$host="localhost";
$password="+FgsO\IV0ZHt}Ug2";
$database = "id20130090_cvds";
$cxn = mysqli_connect($host,$user,$password,$database)
or die ("Couldn’t connect to server");
       if(isset($_POST['get_option'])){

     $districtname = $_POST['get_option'];
     echo "<option>Location</option>";
     $qry=mysqli_query($cxn,"select distinct areaid,areaname from (district join area on district.districtid=area.districtid) where district.districtid='$districtname'");
     while ($row=mysqli_fetch_array($qry)) {?>
     <option class="selectpicker" value="<?php echo $row['areaid'];?>"><?php echo $row['areaname'];?></option>	
     <?php 
     }
}
 ?>
   