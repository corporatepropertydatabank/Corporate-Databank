<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Bootstrap 3 template for corporate business" />
<!-- css -->
<link href="../css/bootstrap.css" rel="stylesheet" />
<link href="../css/cubeportfolio.min.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />
<link href="../css/page.css" rel="stylesheet" />
<link href="../css/jquery-ui.css" rel="stylesheet" />


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>
<body>


<div id="wrapper">
	<header>
			<div class="top">
				<div class="container">
					<div class="row">
					<center>
						<h2 class="text-info">Malawi Central Valuation Data Storage</h2>
						</center>
					</div>
				</div>
			</div>	
			
        <div class="navbar navbar-default navbar-static-top" style="color:#fff;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-header" href="home.php"><img src="../img/logo.PNG" alt="" width="100" height="100" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="home.php"><i class="fa fa-home"></i> Home</a></li>
						<li><a href="addproperty.php"><i class="fa fa-plus"></i>  Add Property</a></li>
                        <li><a href="contact.php"><i class="fa fa-phone"></i>  Contact</a></li>
                        <li><a href="changepassword.php"><i class="fa fa-fw fa-gear"></i> Change Password</a></li>
                        <li><a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log out [<?php echo $fname.'&nbsp;'.$sname;?>]</a></li>
            </ul>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="#"><i class="fa fa-home"></i>&nbsp;&nbsp;&nbsp;Home</a></li>
				</ul>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<div class="container">
    
    <div class="homepage-tagline">
    <div class="homepage-headline">
        <h1>View Your Favourite Property Valuations online!</h1>
        <h2>From 28 Districts in Malawi and Over 1000 locations</h2>
    </div>
</div>
<div class="js-location-search location-search location-search-main-page  location_city_area  ">
    <div class="location-search-inner">
        <form name="" method="post"  role="form" class="form-vertical" action="search_p.php">
                    <div class="city" id="city">
    <label for="cityId">Enter your city</label>
    <div id="wrapper-element-1">
	<select class="form-control select2" name="city" placeholder="Enter a city">            
	<option value="">--Choose District--</option>
<?php  
$result=mysqli_query($cxn,"select * from district") or die(mysql_error());

                    while($row=mysqli_fetch_array($result)){?>
                    <option value="<?php echo $row['districtid'];?>"><?php echo $row['districtname'];?></option>
                    
                <?php }
                 ?>
	</select>
	
	<span style="position: relative; display: inline-block; direction: ltr;" class="twitter-typeahead">
	
	
	<pre style="position: absolute; visibility: hidden; white-space: pre; font-family: &quot;Open Sans&quot;,sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; word-spacing: 0px; letter-spacing: 0px; text-indent: 0px; text-rendering: optimizelegibility; text-transform: none;" aria-hidden="true"></pre>
	
	<span style="position: absolute; top: 100%; left: 0px; z-index: 100; display: none; right: auto;" class="tt-dropdown-menu"><div class="tt-dataset-typeahead-top-cities"></div>
	<div class="tt-dataset-typeahead-more-cities"></div></span></span></div>
</div>
        
                  <div class="area">
    <label for="area" class="required">Enter your area</label>
    <span style="position: relative; display: inline-block; direction: ltr;" class="twitter-typeahead">
	
	<input dir="auto" style="position: relative; vertical-align: top; background-color: transparent;"  id="location" name="location" required="required" data-prefill="location.areaName" class="form-control tt-input" placeholder="Enter Location" type="text">
        
    </span>
</div> 
        
                    
                    
        
        <div class="find-food">
    <button type="submit" id="button" name="submit" class="btn btn-primary btn-block">Show property</button></form>
    </div>
</div>


    </div>
	</section>
	<?php include("../footer.php");?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.min.js"></script>
<script src="../js/modernizr.custom.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.appear.js"></script>
<script src="../js/stellar.js"></script>
<script src="../js/classie.js"></script>
<script src="../js/uisearch.js"></script>
<script src="../js/jquery.cubeportfolio.min.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>
<script src="../js/jquery-ui.js"></script>
<script>
var availableTags =<?php 
$sql = "SELECT areaname FROM area ORDER BY areaname ASC";
    $result = mysqli_query($cxn, $sql) or die("Error " . mysqli_error($cxn));

    $dname_list = array();
    while($row = mysqli_fetch_array($result))
    {
        $dname_list[] = $row['areaname'];
    }
    echo json_encode($dname_list);?>;
$( "#location" ).autocomplete({
	source: availableTags
});
		$(function () {
		$('[data-toggle="tooltip"]').tooltip()
		})
	</script>

	
</body>
</html>