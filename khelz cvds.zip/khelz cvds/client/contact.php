<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Malawi Central Valuation Data Storage</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Bootstrap 3 template for corporate business" />
<!-- css -->
<link href="../css/bootstrap.css" rel="stylesheet" />
<link href="../css/cubeportfolio.min.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />
<link href="../css/page.css" rel="stylesheet" />


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>
<body>


<div id="wrapper">

	<header>
			<div class="top">
				<div class="container">
					<div class="row">
					<center>
						<h2 class="text-info">Malawi Central Valuation Data Storage System</h2>
						</center>
					</div>
				</div>
			</div>	
			
        <div class="navbar navbar-default navbar-static-top" style="color:#fff;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                     <a class="navbar-header" href="home.php"><img src="../img/logo.PNG" alt="" width="100" height="100" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="home.php"><i class="fa fa-home"></i> Home</a></li>
						<li><a href="addproperty.php"><i class="fa fa-plus"></i>  Add Property</a></li>
                        <li class="active"><a href="contact.php"><i class="fa fa-phone"></i>  Contact</a></li>
                        <li><a href="changepassword.php"><i class="fa fa-fw fa-gear"></i> Change Password</a></li>
                        <li><a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log out [<?php echo $fname.'&nbsp;'.$sname;?>]</a></li>
            </ul>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="#"><i class="fa fa-home"></i>  Home</a><i class="icon-angle-right"></i></li>
					<li class="active">Contact</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
			    <h2>Contact us <small>get in touch with us by filling form below</small></h2>
			    <hr class="colorgraph">
			    <div id="sendmessage">Your message has been sent. Thank you!</div>
                <div id="errormessage"></div>
				<?php
include('head.php');
if(isset($_POST['submit']))
{								
$sq="INSERT INTO messages (name,email,message)
VALUES
('$_POST[name]','$_POST[email]','$_POST[message]')";

if (!mysqli_query($cxn,$sq))
  {
  die('Error:1 ' . mysql_error());
  }
        echo "<div class='alert alert-info alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><center><h4>Your Message has been sent</h4></center></div>";
}


?>
                <form action="" method="post" role="form" class="contactForm">
                    <div class="form-group">
                        <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                        <div class="validation"></div>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                        <div class="validation"></div>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                        <div class="validation"></div>
                    </div>
                    
                    <div class="text-center"><button type="submit" name="submit" class="btn btn-theme btn-block btn-md">Send Message</button></div>
                </form>
                <hr class="colorgraph">

			</div>
		</div>
	</div>
	</section>
	<?php include("../footer.php");?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.min.js"></script>
<script src="../js/modernizr.custom.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.appear.js"></script>
<script src="../js/stellar.js"></script>
<script src="../js/classie.js"></script>
<script src="../js/uisearch.js"></script>
<script src="../js/jquery.cubeportfolio.min.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>	
</body>
</html>