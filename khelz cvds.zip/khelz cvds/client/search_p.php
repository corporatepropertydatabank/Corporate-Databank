<?php
include("../connect.php");
if(isset($_POST['submit'])){
	$city = mysqli_real_escape_string($cxn,$_POST['city']);
	$c = str_replace(' ','+', trim($city));
	$l = $_POST['location'];
	
	header("Location:search.php?c=$c&l=$l");
}
	