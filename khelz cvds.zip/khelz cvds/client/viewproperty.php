<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Malawi Central Valuation Data Storage System</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Bootstrap 3 template for corporate business" />
<!-- css -->
<link href="../css/bootstrap.css" rel="stylesheet" />
<link href="../css/cubeportfolio.min.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />
<link href="../css/style2.css" rel="stylesheet" />
<link href="../css/EduSecUserProfile.css" rel="stylesheet" />


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>
<body>


<div id="wrapper">
	<header>
			<div class="top">
				<div class="container">
					<div class="row">
					<center>
						<h2 class="text-info">Malawi Central Valuation Data Storage System</h2>
						</center>
					</div>
				</div>
			</div>	
			
        <div class="navbar navbar-default navbar-static-top" style="color:#fff;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                     <a class="navbar-header" href="home.php"><img src="../img/logo.PNG" alt="" width="100" height="100" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="home.php"><i class="fa fa-home"></i> Home</a></li>
						<li><a href="addproperty.php"><i class="fa fa-plus"></i>  Add Property</a></li>
                        <li><a href="contact.php"><i class="fa fa-phone"></i>  Contact</a></li>
                        <li><a href="changepassword.php"><i class="fa fa-fw fa-gear"></i> Change Password</a></li>
                        <li><a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log out [<?php echo $fname.'&nbsp;'.$sname;?>]</a></li>
            </ul>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="#"><i class="fa fa-home"></i>  Home</a><i class="icon-angle-right"></i></li>
					<li class="active">Property Details</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
	<section id="content4">
	</br>
	<div class="container" >
    
    <article class="vendor list js-vendor-list-vendor-panel" >
<section class="content edusec-user-profile">
<div class="row">
	<div class="col-lg-3 table-responsive ">
	<?php 	
 $query = "SELECT *  from (district join area on district.districtid=area.districtid join property on area.areaid=property.areaid join zone on property.propertyid=zone.propertyid join valuation on property.propertyid=valuation.propertyid) where property.propertyid='$_GET[id]'";
    
    $result = mysqli_query($cxn,$query)or die(mysql_error());
	$nrows = mysqli_num_rows($result);
if($nrows>0){
for ($i=0;$i<$nrows;$i++)
{
$n = $i + 1; #add 1 so numbers don’t start with 0
$row = mysqli_fetch_assoc($result);
extract($row);
}
}
	 ?>
		<div class="col-md-12 text-center">
			<img src="../images/<?php echo $row['propertycondition'];?>" id = 'picture' width='440' height='340' align='center' class='img-thumbnail'  alt="No Image">
			
		</div>
		
	</div>

	<div class="col-lg-9 profile-data">
		<ul class="nav nav-tabs responsive" id = "profileTab">
			<li class="active" id = "personal-tab"><a href="#personal" data-toggle="tab"><i class="fa fa-user"></i> Property Details</a></li>
			<li id = "academic-tab" class="focus"><a href="#academic" data-toggle="tab"><i class="fa fa-graduation-cap"></i> Valuation Details</a></li>
			<li id = "guardians-tab"><a href="#guardians" data-toggle="tab"><i class="fa fa-user"></i> Finance Details</a></li>
							<li ><a href="propertypdf.php?id=<?php echo $_GET['id'];?>" title="PDF [new window]"><i class="fa fa-file-pdf-o"></i> Generate Pdf</a></li>
					</ul>
		 <div id='content3' class="tab-content responsive">
			<div class="tab-pane active" id="personal">
				

<div class="row">
  <div class="col-xs-12">
	<h3 class="page-header">	
	<i class="fa fa-info-circle"></i> <i>Property Details</i>	<div class="pull-right">
					</div>
	</h3>
  </div><!-- /.col -->
</div>

<div class="row">

	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding edusec-bg-row ">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">District</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['districtname'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Location</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['areaname'];?></div>
	  </div>
	</div>

	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Zoning</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['zoning'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Number of Rooms</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['numberofrooms'];?></div>
	  </div>
	</div>


	<div class="col-md-12 col-xs-12 col-sm-12">
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">GEA</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['grossfloorarea'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">NIA</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['NIA'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">GIA</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['GIA'];?></div>
	  </div>
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Floor Type</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['floortype'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Garage</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['garage'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Basement</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['basement'];?></div>
	  </div>
	  
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Encumbrance</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['encumbrance'];?></div>
	  </div>
	  
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Topography</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['topography'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Fixtures and Fittings</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['fixturesandfittings'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Property Type</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['propertytype'];?></div>
	  </div>
	  
	   <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Access</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['access'];?></div>
	  </div>
	  
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Yield</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['yield'];?></div>
	  </div>
	</div>

	
</div> <!---Main Row Div--->
	
			</div>
			<div class="tab-pane" id="academic">
				

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h3 class="page-header">	
	<i class="fa fa-info-circle"></i> <i>Valuation Details</i>	<div class="pull-right">
			</div>
	</h3>
  </div><!-- /.col -->
</div>

<div class="row">
<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding edusec-bg-row ">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Method of Valuation</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['methodofvaluation'];?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Purpose of Valuation</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['purposeofvaluation'];?></div>
	  </div>
	</div>
<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding edusec-bg-row ">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Date of Valuation</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php $date = new DateTime($row["dateofvaluation"]); echo $date->format("F jS, Y");?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Date of Transaction</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php $date = new DateTime($row["dateoftransaction"]); echo $date->format("F jS, Y");?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Type of Tenure</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['typeoftenure'];?></div>
	  </div>
	</div>
</div>
	
			</div>
			<div class="tab-pane" id="guardians">
				
<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h3 class="page-header">	
	<i class="fa fa-info-circle"></i> Finance Details	<div class="pull-right">	</div>
	</h3>
  </div><!-- /.col -->
</div>


<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
  </div><!-- /.col -->
</div>
<div class="row">
	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Rent Per Month</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['rentpermonth']; ?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Market Value</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['marketvalue']; ?></div>
	  </div>
	</div>

	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Property Value</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['askingprice']; ?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss">Transaction Price</div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?php echo $row['transactionprice']; ?></div>
	  </div>
	</div>
</div>
	
			</div>

</div>
				</div>
	</div>
     </div> <!---End Row Div--->
</section>
    </article>  
	</div>
	</section>
	<?php include("../footer.php");?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.min.js"></script>
<script src="../js/modernizr.custom.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.appear.js"></script>
<script src="../js/stellar.js"></script>
<script src="../js/classie.js"></script>
<script src="../js/jquery.cubeportfolio.min.js"></script>
<script src="../js/custom.js"></script>
	
</body>
</html>