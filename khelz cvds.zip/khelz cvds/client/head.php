<?php
include("../connect.php");
if(!isset($_SESSION['userid'])){
echo'
<table width="400" class=table2 align=center >
  <tr>
    <td> <br><center><font color=red size=3><b>User Acess Denied !!!!!!</b></font></center><br><hr color=green width=300 size=1><center> 
	Your Not Authorised to Acess This Page. <br>
<hr color=green width=300 size=1><font color=#FF0000 size=1> Redirecting <<<<< </font><br><br>';
echo  "<meta http-equiv=Refresh content=1;url=../index.php>";
echo '</center></td>
  </tr>
</table> ';
#echo "</center>";
exit();
}
$userid=$_SESSION['userid'];
//Get user information
$qry="SELECT * FROM (user join client on user.userid=client.userid) WHERE user.userid = '$userid' LIMIT 1";
$result=$cxn->query($qry);
while($row=mysqli_fetch_assoc($result)){
	$fname=$row['fname'];
	$sname=$row['sname'];
}