<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Change Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Bootstrap 3 template for corporate business" />
<!-- css -->
<link href="../css/bootstrap.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />
<link href="../css/page.css" rel="stylesheet" />
  <link rel="stylesheet" href="../css/sweetalert.css">


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />

</head>
<body>


<div id="wrapper">

	<header>
			<div class="top">
				<div class="container">
					<div class="row">
					<center>
						<h2 class="text-info">Malawi Central Valuation Data Storage</h2>
						</center>
					</div>
				</div>
			</div>	
			
        <div class="navbar navbar-default navbar-static-top" style="color:#fff;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                     <a class="navbar-header" href="home.php"><img src="../img/logo.PNG" alt="" width="100" height="100" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="home.php"><i class="fa fa-home"></i> Home</a></li>
						<li><a href="addproperty.php"><i class="fa fa-plus"></i>  Add Property</a></li>
                        <li><a href="contact.php"><i class="fa fa-phone"></i>  Contact</a></li>
                        <li class="active"><a href="changepassword.php"><i class="fa fa-fw fa-gear"></i> Change Password</a></li>
                        <li><a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log out [<?php echo $fname.'&nbsp;'.$sname;?>]</a></li>
            </ul>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="home.php"><i class="fa fa-home"></i>  Home</a><i class="icon-angle-right"></i></li>
					<li class="active">Change Password</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<?php 
if (isset($_POST['submit'])) {
	$errors = "";
	$oldpassword 	= $_POST['oldpass'];
	$newpassword1	= $_POST['pass1'];
	$newpassword2	= $_POST['pass2'];
	if($newpassword1!==$newpassword2){
		$errors.="<div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>The New Passwords do not Match</div>";
	}

	$user_id = $_SESSION['userid'];
	$res = $cxn->query("SELECT password FROM user WHERE userid=$user_id");
	while ($row = mysqli_fetch_assoc($res)) {
		$cpass = $row['password'];
	}

	if($cpass!==md5($oldpassword)){
		$errors.="<div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>The Current Password is Incorrect</div>";
	}	

	if($errors==""){
		$insertpassword = md5($newpassword1);
		$qry = "UPDATE user SET password='$insertpassword' WHERE userid='$user_id'";
		$cxn->query($qry) or die($qry);
		$errors.="<div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>Password is Renewed</div>";
	}
}

?>

					   <div style ="width:50%; margin-left:25%;margin-right:25%;">
					   <?php 
				if(!isset($_POST['submit'])):
			?>
			
			<?php else: if($errors!=""): ?>

			<?php echo $errors ?>

			<?php endif; endif;?>
<form role="form" action="changepassword.php" autocomplete="off" method="post" style="margin-left: 15px;">
					<div class="form-group">
						<label for="oldpass">Current Password</label>
						<input type="password" class="form-control" id="oldpass" name="oldpass" placeholder="Enter Current Password" value="">
					</div>

					<div class="form-group">
						<label for="pass1">New Password</label>
						<input type="password" class="form-control" id="pass1" name="pass1" placeholder="Enter Password" value="">
					</div>

					<div class="form-group">
						<label for="pass2">Verify New Password</label>
						<input type="password" class="form-control" id="pass2" name="pass2" placeholder="Re-enter Password" value="">
					</div>
		
					<button type="submit" name="submit" class="btn btn-success">Change Password</button>
				</form>

				</div>

	
	</section>
	<?php include("../footer.php");?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
  <script src="../js/sweetalert-dev.js"></script>
<script src="../js/jquery.min.js"></script>
<script src="../js/modernizr.custom.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.appear.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>
	
</body>
</html>