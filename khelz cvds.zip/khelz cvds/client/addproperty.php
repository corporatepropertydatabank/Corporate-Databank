<?php 
@session_start();
include('head.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Add Property</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Bootstrap 3 template for corporate business" />
<!-- css -->
<link href="../css/bootstrap.css" rel="stylesheet" />
<link href="../css/cubeportfolio.min.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />
<link href="../css/page.css" rel="stylesheet" />
<link class="jsbin" href="../css/jquery-ui.css" rel="stylesheet" type="text/css" />
<script class="jsbin" src="../js/jquery.min.js"></script>
<script class="jsbin" src="../jsjquery-ui.js"></script>

<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />
<script type="text/javascript">

function getdistrict(val)
{
  //alert(val); 
 $.ajax({
     type: 'post',
     url: 'finddistrict.php',
     data: {
       get_option:val
     },
     success: function (response) {
       // alert(response);
       document.getElementById("area").innerHTML=response; 
     }
   });
}
</script>
  <script>
  
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

  </script>
</head>
<body>


<div id="wrapper">
	<!-- start header -->
	<header>
			<div class="top">
				<div class="container">
					<div class="row">
					<center>
						<h2 class="text-info">Malawi Central Valuation Data Storage</h2>
						</center>
					</div>
				</div>
			</div>	
			
        <div class="navbar navbar-default navbar-static-top" style="color:#fff;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                     <a class="navbar-header" href="home.php"><img src="../img/logo.PNG" alt="" width="100" height="100" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="home.php"><i class="fa fa-home"></i> Home</a></li>
                        <li class="active"><a href="addproperty.php"><i class="fa fa-plus"></i>  Add Property</a></li>
						<li><a href="contact.php"><i class="fa fa-phone"></i>  Contact</a></li>
                        <li><a href="changepassword.php"><i class="fa fa-fw fa-gear"></i> Change Password</a></li>
                        <li><a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log out [<?php echo $fname.'&nbsp;'.$sname;?>]</a></li>
            </ul>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="home.php"><i class="fa fa-home"></i>  Home</a><i class="icon-angle-right"></i></li>
					<li class="active">Add Property</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<div class="container">
		<div>
			<div class="col-md-12 ">
			<div class="tab-content">
                                <div class="col-md-12 ">
								<br>
								<div class="col-md-8 col-md-offset-2">
								<hr class="colorgraph">
                                    <form role="form" action="addpropertyphp.php?id=<?php echo $_SESSION['userid'];?>" class="contactForm" method = "post" enctype="multipart/form-data">
		<div class="form-group">
		<label for="name">District</label>
		<select class="form-control" id ="district" name="district" onchange="getdistrict(this.value);">
		 <option value="">--select--</option>
<?php  
$result=mysqli_query($cxn,"select * from district") or die(mysql_error());

                    while($row=mysqli_fetch_array($result)){?>
                    <option value="<?php echo $row['districtid'];?>"><?php echo $row['districtname'];?></option>
                    
                <?php }
                 ?>
</select>
		<label for="area">Location</label>
		<select class="form-control" id ="area" name="area">
		<?php
		while ($row=mysqli_fetch_array($result)) {?>
     <option value="<?php echo $row['areaid'];?>"><?php echo $row['areaname'];}?></option>	
	 
</select>
		<label for="name">Property Type</label>
		<input type="text" class="form-control"   name = "propertytype" placeholder = "Property Type">
		<label for="name">Number Of Rooms</label>
		<input type="text" class="form-control"  name = "numberofrooms" placeholder = "Number Of Rooms">
		<label for="name">GEA</label>
		<input type="text" class="form-control"  name = "grossfloorarea" placeholder = "GEA">
		<label for="name">NIA</label>
		<input type="text" class="form-control"   name = "NIA" placeholder = "NIA">
		<label for="name">GIA</label>
		<input type="text" class="form-control"   name = "GIA" placeholder = "GIA">
		<label for="name">Zoning</label>
<select class="form-control" name="zoning">
<option>Commercial</option>
<option>Industrial</option>
<option>Agricultural</option>
<option>Residential</option>
</select>

<label for="name">Rent Per Month</label>
		<input type="text" class="form-control"  name = "rentpermonth" placeholder = "Rent Per Month">
		<label for="name">Floor Type</label>
<select class="form-control" name="floortype">
<option>Cement screed</option>
<option>Ceramic tiles</option>
<option>Vinyl</option>
<option>Parquet</option>
<option>Quart tile</option>
</select>

<label for="name">Garage</label>
<select class="form-control" name="garage">
<option>Available</option>
<option>Not Available</option>
</select>

<label for="name">Fixtures and Fittings</label>
<select class="form-control" name="fixturesandfittings">
<option>Well fitted with services</option>
<option>Partially fitted with services</option>
<option>No services available</option>
</select>

<label for="name">Topography</label>
<select class="form-control" name="topography">
<option>Generally Flat</option>
<option>Sloppy</option>
</select>
<label for="name">Basement</label>
<select class="form-control" name="basement">
<option>Available</option>
<option>Not Available</option>
</select>
		<label for="name">Encumbrance</label>
		<select class="form-control" name ="encambrance">
		<option>Available</option>
		<option>Not Available</option>
		</select>
		
		
<label for="name">Access</label>
<select class="form-control" name="access">
<option>Tarmac Road</option>
<option>Earth Road</option>
<option>Gravel Road</option>
</select>

<label for="name">Property Value</label>
		<input type="text" class="form-control"   name = "askingprice" placeholder = "Property Value">
		
<label for="name">Market Value</label>
		<input type="text" class="form-control"   name = "marketvalue" placeholder = "Market Value">
		
										<br><div class="form-group">
											<img id="blah" src="#" alt="" /><br>
                                            <label>Property Condition</label>
                                            <input type="file" name="myfile" onchange="readURL(this);">
                                        </div>
										
										<label for="name">Method of Valuation</label>
										<select class="form-control" name ="methodofvaluation">
										<option>Comparable</option>
										<option>Income/profit</option>
										<option>Residual</option>
										<option>Cost</option>
										<option>Investment</option>
										<option>Plant and machinery</option>
										</select>
										
										<label for="name">Purpose of Valuation</label>
										<select class="form-control" name ="purposeofvaluation">
										<option>Taxation</option>
										<option>Mortgage</option>
										<option>Insurance</option>
										<option>Compensation</option>
										<option>Asking price</option>
										</select>
		
		<label for="name">Date of Valuation</label>
		<input type="text" id="datepicker" class="form-control"   name = "dateofvaluation" placeholder = "Date of Valuation">
		<label for="name">Date of Transaction</label>
		<input type="text" id="datepicker1" class="form-control"   name = "dateoftransaction" placeholder = "Date of Transaction">
		
		<label for="name">Yield</label>
		<input type="text" class="form-control"   name = "yield" placeholder = "Yield">
		
		<label for="name">Transaction Price</label>
		<input type="text" class="form-control"   name = "trans" placeholder = "Transaction Price">
		
		<label for="name">Type of Tenure</label>
										<select class="form-control" name ="typeoftenure">
										<option>Leasehold</option>
										<option>Freehold</option>
										<option>Customary Estate</option>
										</select>
</div>
<div class="form-group">
<center><div class="col-sm-offset-2 col-sm-7">
<button type="submit" class="btn btn-success" name = "submit" value = "Register">Register</button>
</div></center>

</div>

</form>
                                </div>
								</div>
                            </div>
			</div>
		</div>
		
	</div>
	</section>
	<?php include("../footer.php");?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster the pages load faster -->
<script src="../js/jquery.min.js"></script>
<script src="../js/modernizr.custom.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.appear.js"></script>
<script src="../js/stellar.js"></script>
<script src="../js/classie.js"></script>
<script src="../js/uisearch.js"></script>
<script src="../js/jquery.cubeportfolio.min.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>
<script src="../js/jquery-ui.js"></script>
<script>
$( "#datepicker" ).datepicker({
	inline: true
});
</script>
<script>
$( "#datepicker1" ).datepicker({
	inline: true
});
</script>
</body>
</html>