-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 19, 2017 at 10:03 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cvds`
--

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `areaid` int(20) NOT NULL AUTO_INCREMENT,
  `areaname` varchar(50) DEFAULT NULL,
  `districtid` int(20) DEFAULT NULL,
  PRIMARY KEY (`areaid`),
  KEY `districtid` (`districtid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=95 ;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`areaid`, `areaname`, `districtid`) VALUES
(1, 'Ndirande', 1),
(2, 'Chilobwe', 1),
(3, 'Chinsapo', 2),
(4, 'Matawale', 2),
(5, 'mbayani', 1),
(6, 'makhetha', 1),
(7, 'Machinjiri', 1),
(8, 'Chileka', 1),
(9, 'Chirimba', 1),
(10, 'Naperi', 1),
(11, 'Bunda', 2),
(12, 'Chilumba', 11),
(13, 'kanjedza', 1),
(14, 'chinyonga', 1),
(15, 'chitawira', 1),
(16, 'Nkolokosa', 1),
(17, 'sigelege', 1),
(18, 'chirimba', 1),
(19, 'BCA', 1),
(20, 'Bangwe', 1),
(21, 'Chigumula', 1),
(22, 'Ludzu', 1),
(23, 'CI', 1),
(24, 'Manase', 1),
(25, 'Manja', 1),
(26, 'Mandala', 1),
(27, 'Limbe', 1),
(28, 'Kachere', 1),
(29, 'Mbayani', 1),
(30, 'Soche East', 1),
(31, 'Manje', 1),
(32, 'Jenda', 25),
(33, 'Embagweni', 25),
(34, 'Enukweni', 25),
(35, 'Ekwendeni', 25),
(36, 'Zolozolo', 25),
(37, 'Katoto', 25),
(38, 'Chiwabvi', 25),
(39, 'Mchenga utuwa', 25),
(40, 'Luwinga', 25),
(41, 'Mzuzu maintown', 25),
(42, 'Chikangawa', 25),
(43, 'Sadzi', 9),
(45, 'Mpunga', 9),
(46, 'New road', 9),
(47, 'Chizalo', 9),
(48, 'Matete', 9),
(49, 'Jali', 9),
(50, 'Matawale', 9),
(51, 'Chinamwali', 9),
(52, 'Songani', 9),
(53, 'Jokala', 9),
(54, 'Old Naisi', 9),
(55, 'Naisi', 9),
(56, 'Domasi', 9),
(57, 'Malosa', 9),
(58, 'Namilongo', 9),
(59, 'Thondwe', 9),
(60, 'Namazi', 9),
(61, 'Nitiya', 9),
(62, 'Changalume', 9),
(63, 'Chikanda', 9),
(64, 'Thundu', 9),
(65, 'Govala', 9),
(66, 'Msondole', 9),
(67, 'Bimbi', 9),
(68, 'Nancholi', 1),
(70, 'Chirunga', 9),
(71, 'Manga sanja', 9),
(72, 'area 1', 2),
(73, 'area 2', 2),
(74, 'area 4', 2),
(75, 'area 5', 2),
(76, 'area 6', 2),
(77, 'area 7', 2),
(78, 'area 8', 2),
(79, 'area 9', 2),
(80, 'area 10', 2),
(81, 'area 11', 2),
(82, 'area 12', 2),
(83, 'area 14', 2),
(84, 'area 15', 2),
(85, 'area 16', 2),
(86, 'area 17', 2),
(87, 'area 18', 2),
(88, 'area 19', 2),
(89, 'area 20', 2),
(90, 'area 21', 2),
(91, 'area 22', 2),
(92, 'area 24', 2),
(93, 'area 25', 2),
(94, 'area 26', 2);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `clientid` int(20) NOT NULL AUTO_INCREMENT,
  `userid` int(20) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `sname` varchar(50) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`clientid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`clientid`, `userid`, `fname`, `sname`, `sex`, `address`, `contact`) VALUES
(1, 1, 'Atusaye', 'Kanyenda', 'male', 'makata', '0884469775'),
(2, 2, 'Steven', 'Douglas', 'male', 'hhhh', '0999'),
(3, 3, 'Atusaye', 'Kanyanda', 'Male', 'Chinyonga', '08888888888'),
(4, 4, 'peace', 'msoza', 'Female', 'zomba', '0881512171');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
  `districtid` int(20) NOT NULL AUTO_INCREMENT,
  `districtname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`districtid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`districtid`, `districtname`) VALUES
(1, 'Blantyre'),
(2, 'lilongwe'),
(3, 'Balaka'),
(4, 'Salima'),
(5, 'Nsanje'),
(6, 'Thyolo'),
(7, 'Mulanje'),
(8, 'Phalombe'),
(9, 'Zomba'),
(10, 'Mwanza'),
(11, 'Karonga'),
(12, 'Dowa'),
(13, 'Dedza'),
(14, 'Ntcheu'),
(15, 'Ntchisi'),
(16, 'Mangochi'),
(17, 'Machinga'),
(18, 'Chitipa'),
(19, 'Nkhatabay'),
(20, 'Likoma'),
(21, 'Chiradzulu'),
(22, 'Neno'),
(23, 'Mchinji'),
(24, 'Rumphi'),
(25, 'Mzimba'),
(26, 'Chikhwawa'),
(27, 'Kasungu'),
(28, 'Nkhotakota');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `Loginid` int(22) NOT NULL AUTO_INCREMENT,
  `user` int(22) NOT NULL,
  `username` varchar(22) NOT NULL,
  `usertype` varchar(22) DEFAULT NULL,
  `loginTime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Loginid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Loginid`, `user`, `username`, `usertype`, `loginTime`) VALUES
(1, 1, 'dd', 'admin', '2017-01-20 09:05:29'),
(2, 1, 'dd', 'admin', '2017-01-20 09:05:41'),
(3, 2, 'as', 'client', '2017-01-20 10:52:03'),
(4, 1, 'dd', 'admin', '2017-01-20 10:53:51'),
(5, 2, 'as', 'client', '2017-01-20 12:21:11'),
(6, 2, 'as', 'client', '2017-01-20 12:21:21'),
(7, 1, 'dd', 'admin', '2017-01-20 16:42:55'),
(8, 1, 'dd', 'admin', '2017-01-20 16:43:09'),
(9, 2, 'as', 'client', '2017-01-20 17:06:18'),
(10, 2, 'as', 'client', '2017-01-20 17:06:54'),
(11, 1, 'dd', 'admin', '2017-01-20 17:07:02'),
(12, 1, 'dd', 'admin', '2017-01-20 17:07:37'),
(13, 2, 'as', 'client', '2017-01-20 17:07:54'),
(14, 1, 'dd', 'admin', '2017-01-20 17:08:02'),
(15, 2, 'as', 'client', '2017-01-20 17:17:26'),
(16, 1, 'dd', 'admin', '2017-01-20 17:17:42'),
(17, 3, 'Atusaye', 'client', '2017-01-20 17:18:59'),
(18, 3, 'Atusaye', 'client', '2017-01-20 17:22:08'),
(19, 1, 'dd', 'admin', '2017-01-20 17:28:45'),
(20, 1, 'dd', 'admin', '2017-01-20 17:38:04'),
(21, 2, 'as', 'client', '2017-01-20 18:08:37'),
(22, 2, 'as', 'client', '2017-01-20 18:08:55'),
(23, 1, 'dd', 'admin', '2017-01-20 18:11:23'),
(24, 2, 'as', 'client', '2017-01-20 18:11:40'),
(25, 2, 'as', 'client', '2017-03-07 17:48:57'),
(26, 1, 'dd', 'admin', '2017-03-07 17:53:27'),
(27, 2, 'as', 'client', '2017-03-07 17:55:33'),
(28, 1, 'dd', 'admin', '2017-03-07 17:57:25'),
(29, 1, 'dd', 'admin', '2017-03-08 15:32:49'),
(30, 2, 'as', 'client', '2017-03-08 15:36:55'),
(31, 2, 'as', 'client', '2017-03-10 16:42:44'),
(32, 2, 'as', 'client', '2017-03-10 16:43:27'),
(33, 1, 'dd', 'admin', '2017-03-10 16:52:18'),
(34, 4, 'peace msoza', 'client', '2017-03-10 16:57:32'),
(35, 4, 'peace msoza', 'client', '2017-03-10 16:59:09'),
(36, 4, 'peace msoza', 'client', '2017-03-10 17:02:06'),
(37, 2, 'as', 'client', '2017-03-11 13:59:57'),
(38, 1, 'dd', 'admin', '2017-03-11 14:47:06'),
(39, 2, 'as', 'client', '2017-03-11 14:49:48'),
(40, 1, 'dd', 'admin', '2017-03-11 14:51:42'),
(41, 1, 'dd', 'admin', '2017-03-11 14:58:16'),
(42, 2, 'as', 'client', '2017-03-11 18:17:54'),
(43, 1, 'dd', 'admin', '2017-03-11 18:26:26'),
(44, 2, 'as', 'client', '2017-03-11 18:39:03'),
(45, 1, 'dd', 'admin', '2017-03-11 18:42:41'),
(46, 1, 'dd', 'admin', '2017-03-11 19:08:20'),
(47, 2, 'as', 'client', '2017-04-01 15:03:14');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE IF NOT EXISTS `property` (
  `propertyid` int(20) NOT NULL AUTO_INCREMENT,
  `userid` int(20) NOT NULL,
  `propertytype` varchar(50) DEFAULT NULL,
  `propertycondition` varchar(50) DEFAULT NULL,
  `numberofrooms` varchar(50) DEFAULT NULL,
  `grossfloorarea` varchar(50) DEFAULT NULL,
  `rentpermonth` varchar(50) DEFAULT NULL,
  `floortype` varchar(50) DEFAULT NULL,
  `garage` varchar(50) DEFAULT NULL,
  `basement` varchar(50) DEFAULT NULL,
  `encumbrance` varchar(50) DEFAULT NULL,
  `areaid` int(20) DEFAULT NULL,
  `fixturesandfittings` varchar(50) DEFAULT NULL,
  `access` varchar(50) DEFAULT NULL,
  `topography` varchar(50) DEFAULT NULL,
  `askingprice` varchar(50) DEFAULT NULL,
  `marketvalue` varchar(50) DEFAULT NULL,
  `NIA` varchar(50) DEFAULT NULL,
  `GIA` varchar(50) DEFAULT NULL,
  `transactionprice` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`propertyid`),
  KEY `areaid` (`areaid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`propertyid`, `userid`, `propertytype`, `propertycondition`, `numberofrooms`, `grossfloorarea`, `rentpermonth`, `floortype`, `garage`, `basement`, `encumbrance`, `areaid`, `fixturesandfittings`, `access`, `topography`, `askingprice`, `marketvalue`, `NIA`, `GIA`, `transactionprice`, `status`) VALUES
(14, 1, 'Building', '1.jpg', '100', '100m2', '1000,000', 'Cement screed', 'Available', 'Available', 'Available', 1, 'Well fitted with services', 'Tarmac Road', 'Generally Flat', '100,000', '100,000', '90', '80', NULL, 'enabled'),
(15, 1, 'Residential', '8.jpg', '4', '20m2', '200,000', 'Cement screed', 'Available', 'Available', 'Available', 2, 'Well fitted with services', 'Tarmac Road', 'Generally Flat', '2,000,000', '2,000,000', '10m2', '15m2', '3,000,000', 'enabled'),
(16, 3, 'House', '5.jpg', '2', '100m2', '1000,000', 'Cement screed', 'Available', 'Available', 'Available', 12, 'Well fitted with services', 'Tarmac Road', 'Generally Flat', '2,000,000', '2,000,000', '10m2', '15m2', '4,000,000', 'enabled'),
(17, 3, 'House', 'img3.jpg', '9', '60m2', '30,000', 'Cement screed', 'Available', 'Available', 'Available', 12, 'Well fitted with services', 'Tarmac Road', 'Generally Flat', '5,000,000', '6,000,000', '60m2', '60m2', '10,000,000', 'enabled'),
(20, 2, 'ensuite', '491521.jpg', '4', '200 m2', 'k 200 000', 'Cement screed', 'Available', 'Available', 'Not Available', 5, 'Well fitted with services', 'Tarmac Road', 'Generally Flat', 'k 20 000 000', 'k 25 000 000', '160 m2', '180 m2', 'k 24 000 000', 'enabled'),
(21, 2, 'ff', '491522.jpg', '66', '55', '55', 'Cement screed', 'Available', 'Available', 'Available', 11, 'Well fitted with services', 'Tarmac Road', 'Generally Flat', '55', '55', '55', '55', '88', 'disabled'),
(22, 2, '', '0', '', '', '', 'Cement screed', 'Available', 'Available', 'Available', 4, 'Well fitted with services', 'Tarmac Road', 'Generally Flat', '', '', '', '', '', 'disabled');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userid` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `usertype` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `usertype`, `password`, `status`) VALUES
(1, 'dd', 'admin', '1aabac6d068eef6a7bad3fdf50a05cc8', 'active'),
(2, 'as', 'client', 'f970e2767d0cfe75876ea857f92e319b', 'active'),
(3, 'Atusaye', 'client', 'e45bf49771870a80bfbb3c3b3b70f5c1', 'active'),
(4, 'peace msoza', 'client', '607579cf9d16702db771e0fd1bd21566', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `valuation`
--

CREATE TABLE IF NOT EXISTS `valuation` (
  `valuationid` int(20) NOT NULL AUTO_INCREMENT,
  `purposeofvaluation` varchar(50) DEFAULT NULL,
  `methodofvaluation` varchar(50) DEFAULT NULL,
  `dateofvaluation` varchar(15) DEFAULT NULL,
  `yield` varchar(50) DEFAULT NULL,
  `dateoftransaction` varchar(15) DEFAULT NULL,
  `typeoftenure` varchar(50) DEFAULT NULL,
  `propertyid` int(20) DEFAULT NULL,
  PRIMARY KEY (`valuationid`),
  KEY `propertyid` (`propertyid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `valuation`
--

INSERT INTO `valuation` (`valuationid`, `purposeofvaluation`, `methodofvaluation`, `dateofvaluation`, `yield`, `dateoftransaction`, `typeoftenure`, `propertyid`) VALUES
(10, 'Taxation', 'Comparable', '01/05/2017', 'mmm', '01/17/2017', 'Leasehold', 14),
(11, 'Taxation', 'Comparable', '01/04/2017', '10%', '01/31/2017', 'Leasehold', 15),
(12, 'Taxation', 'Comparable', '01/17/2017', '5%', '04/13/2016', 'Customary Estate', 16),
(13, 'Taxation', 'Comparable', '01/31/2017', '9%', '02/28/2017', 'Customary Estate', 17),
(16, 'Asking price', 'Comparable', '03/11/2017', '20%', '03/14/2017', 'Leasehold', 20),
(17, 'Taxation', 'Comparable', '04/14/2017', '12', '04/28/2017', 'Leasehold', 21),
(18, 'Taxation', 'Comparable', '', '', '', 'Leasehold', 22);

-- --------------------------------------------------------

--
-- Table structure for table `zone`
--

CREATE TABLE IF NOT EXISTS `zone` (
  `zoneid` int(20) NOT NULL AUTO_INCREMENT,
  `zoning` varchar(50) DEFAULT NULL,
  `propertyid` int(20) DEFAULT NULL,
  PRIMARY KEY (`zoneid`),
  KEY `propertyid` (`propertyid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `zone`
--

INSERT INTO `zone` (`zoneid`, `zoning`, `propertyid`) VALUES
(10, 'Commercial', 14),
(11, 'Residential', 15),
(12, 'Commercial', 16),
(13, 'Commercial', 17),
(16, 'Residential', 20),
(17, 'Commercial', 21),
(18, 'Commercial', 22);

--
-- Constraints for dumped tables
--
CREATE TABLE IF NOT EXISTS `messages` (
  `meid` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`meid`)
);
--
-- Constraints for table `area`
--
ALTER TABLE `area`
  ADD CONSTRAINT `area_ibfk_1` FOREIGN KEY (`districtid`) REFERENCES `district` (`districtid`);

--
-- Constraints for table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `client_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`);

--
-- Constraints for table `property`
--
ALTER TABLE `property`
  ADD CONSTRAINT `property_ibfk_1` FOREIGN KEY (`areaid`) REFERENCES `area` (`areaid`),
  ADD CONSTRAINT `property_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`);

--
-- Constraints for table `valuation`
--
ALTER TABLE `valuation`
  ADD CONSTRAINT `valuation_ibfk_1` FOREIGN KEY (`propertyid`) REFERENCES `property` (`propertyid`);

--
-- Constraints for table `zone`
--
ALTER TABLE `zone`
  ADD CONSTRAINT `zone_ibfk_1` FOREIGN KEY (`propertyid`) REFERENCES `property` (`propertyid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
